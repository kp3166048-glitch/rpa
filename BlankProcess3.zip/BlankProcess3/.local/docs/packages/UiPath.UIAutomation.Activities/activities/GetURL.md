# Get URL

Returns the URL from the current browser.

**Package:** `UiPath.UIAutomation.Activities`
**Category:** UI Automation.Browser
**Assembly:** `UiPath.UIAutomationNext.Activities`
**Class Name:** `UiPath.UIAutomationNext.Activities.NGetUrl`
**Required Scope:** `UiPath.UIAutomationNext.Activities.NApplicationCard`

## Properties

### Configuration

| Name | Display Name | Kind | Type | Default | Required | Description |
|------|-------------|------|------|---------|----------|-------------|
| `WaitForReady` | Wait for page load | InArgument | [`NWaitForReady`](common/NWaitForReady.md) |  |  | Before performing the action, wait for the application to become ready to accept input. The options are: None -- does not wait for the target to be ready; Interactive -- waits until only a part of the app is loaded; Complete -- waits for the entire app to be loaded. |

### Output

| Name | Display Name | Type | Description |
|------|-------------|------|-------------|
| `CurrentUrl` | Current URL | `string` | Where to save the current url. |

### Common

| Name | Display Name | Kind | Type | Default | Required | Description |
|------|-------------|------|------|---------|----------|-------------|
| `ContinueOnError` | Continue on error | InArgument | `bool` |  |  | Continue executing the activities in the automation if this activity fails. The default value is False. |
| `Timeout` | Timeout | InArgument | `double` |  |  | The amount of time (in seconds) to wait for the operation to be performed before generating an error. The default value is 30 seconds. |
| `DelayAfter` | Delay after | InArgument | `double` |  |  | Delay (in seconds) after this activity is completed, before next activity starts. The default amount of time is 0.3 seconds. |
| `DelayBefore` | Delay before | InArgument | `double` |  |  | Delay (in seconds) to wait before executing this activity. The default amount of time is 0.2 seconds. |

## XAML Example

Run `uip rpa --help` to find the command that retrieves the default XAML for an activity, then run it with the class name `UiPath.UIAutomationNext.Activities.NGetUrl`.

## Notes

- This activity must be placed inside a **Use Application/Browser** (`NApplicationCard`) scope.
- Returns the URL of the currently active browser tab.
- Use the `WaitForReady` option to ensure the page is fully loaded before retrieving the URL.
