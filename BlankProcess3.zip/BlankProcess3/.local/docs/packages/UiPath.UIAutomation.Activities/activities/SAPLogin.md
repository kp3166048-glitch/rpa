# SAP Login

Use the activity to log into an SAP system.

**Package:** `UiPath.UIAutomation.Activities`
**Category:** UI Automation.SAP
**Assembly:** `UiPath.UIAutomationNext.Activities`
**Class Name:** `UiPath.UIAutomationNext.Activities.NSAPLogin`
**Required Scope:** `UiPath.UIAutomationNext.Activities.NApplicationCard`

## Properties

### Input

| Name | Display Name | Kind | Type | Required | Default | Placeholder | Description |
|------|-------------|------|------|----------|---------|-------------|-------------|
| `Username` | Username | InArgument | `string` |  |  |  | The username that you want to use for logging in. Text must be quoted. |
| `SecurePassword` | Secure Password | InArgument | `SecureString` |  |  |  | The secure text to be written in the Password field. Note: This field supports only SecureString variables. |
| `Password` | Password | InArgument | `string` |  |  |  | The password you want to use to log in. Text must be quoted. |
| `Client` | Client | InArgument | `string` |  |  |  | The SAP client number you want to log into. Text must be quoted. |
| `Language` | Language | InArgument | `string` |  |  |  | Decide which language you want to use to display screens, menus, and fields. Text must be quoted. |
| `Option` | Multiple Logon Option | Property | [`NMultiLogonOption`](#nmultilogonoption) |  |  |  | License Information for Multiple Logon opens if a user attempts to log onto the system several times. |
| `InUiElement` | Input element | InArgument | [`UiElement`](common/UiElement.md) |  |  |  | The Input UI Element defines the screen element that the activity will be executed on. |

### Output

| Name | Display Name | Type | Description |
|------|-------------|------|-------------|
| `OutUiElement` | SAP Session Window | [`UiElement`](common/UiElement.md) |  |

### Common

| Name | Display Name | Kind | Type | Default | Description |
|------|-------------|------|------|---------|-------------|
| `ContinueOnError` | Continue on error | InArgument | `bool` |  | Continue executing the activities in the automation if this activity fails. The default value is False. |
| `Timeout` | Timeout | InArgument | `double` |  | The amount of time (in seconds) to wait for the operation to be performed before generating an error. The default value is 30 seconds. |
| `DelayAfter` | Delay after | InArgument | `double` |  | Delay (in seconds) after this activity is completed, before next activity starts. The default amount of time is 0.3 seconds. |
| `DelayBefore` | Delay before | InArgument | `double` |  | Delay (in seconds) to wait before executing this activity. The default amount of time is 0.2 seconds. |

## Enums

### NMultiLogonOption

`UiPath.UIAutomationNext.Enums.NMultiLogonOption`

How to handle existing logons when starting a new session.

| Value | Description |
|-------|-------------|
| `NMultiLogonOption.Single` | Continue with this logon and end any other logons. |
| `NMultiLogonOption.Multiple` | Continue with this logon, without ending any other logons. |
| `NMultiLogonOption.Terminate` | Terminate this logon. |

## XAML Example

Run `uip rpa --help` to find the command that retrieves the default XAML for an activity, then run it with the class name `UiPath.UIAutomationNext.Activities.NSAPLogin`.

## Notes

- Before automating SAP, read [`sap-guide.md`](../references/sap-guide.md).
- This activity must be placed inside a `UiPath.UIAutomationNext.Activities.NSAPLogon` or `UiPath.UIAutomationNext.Activities.NApplicationCard` scope.
